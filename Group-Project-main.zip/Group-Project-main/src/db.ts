import mysql from "mysql2/promise";

const pool = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "Gurleen@27052004",
  database: "garden_with_us",
});

export default pool;
